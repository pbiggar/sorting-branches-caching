#include "predictor.h"

#include <string.h>

#if _USE_SOFTWARE_PREDICTOR
	
static char state_names[4][20] = 
{
	"NT saturated",
	"NT",
	"T",
	"T saturated"
};

void
init_predictor(struct predictor* pred)
{
	memset(pred, 0, sizeof(struct predictor));
	/*pred->state = NOT_TAKEN_SATURATED; */
	pred->state = TAKEN;
}

void 
branch_taken(struct predictor* pred)
{
	int s = pred->state;
	pred->branch_count[s]++;
	pred->taken_count[s]++;

	/* check what was predicted */
	if (pred->state >= TAKEN) pred->correct_count[s]++; 
	else pred->incorrect_count[s]++;

	/* need to update the predictor? */
	if (pred->state != TAKEN_SATURATED) pred->state++;
		
}

void 
branch_not_taken(struct predictor* pred)
{
	int s = pred->state;
	pred->branch_count[s]++;
	pred->not_taken_count[s]++;

	/* check what was predicted */
	if (pred->state <= NOT_TAKEN) pred->correct_count[s]++; 
	else pred->incorrect_count[s]++;

	/* need to update the predictor? */
	if (pred->state != NOT_TAKEN_SATURATED) pred->state--;
}

void
dump_predictor_info(FILE* file, struct predictor* pred, char* name)
{
	fprintf(file,	"%s:"
					"states                     %13s %13s %13s %13s %13s\n"
					"branch_count:              %13d %13d %13d %13d %13d\n"
					"correct_count:             %13d %13d %13d %13d %13d\n"
					"incorrect_count:           %13d %13d %13d %13d %13d\n"
					"taken_count:               %13d %13d %13d %13d %13d\n"
					"not_taken_count:           %13d %13d %13d %13d %13d\n"
					"current state:             %13s\n\n",
					name,
					state_names[0], state_names[1],
					state_names[2], state_names[3], "Total",
					pred->branch_count[0], pred->branch_count[1],
					pred->branch_count[2], pred->branch_count[3],
					pred->branch_count[0] + pred->branch_count[1] +
					pred->branch_count[2] + pred->branch_count[3],
					pred->correct_count[0], pred->correct_count[1],
					pred->correct_count[2], pred->correct_count[3],
					pred->correct_count[0] + pred->correct_count[1] +
					pred->correct_count[2] + pred->correct_count[3],
					pred->incorrect_count[0], pred->incorrect_count[1],
					pred->incorrect_count[2], pred->incorrect_count[3],
					pred->incorrect_count[0] + pred->incorrect_count[1] +
					pred->incorrect_count[2] + pred->incorrect_count[3],
					pred->taken_count[0], pred->taken_count[1],
					pred->taken_count[2], pred->taken_count[3],
					pred->taken_count[0] + pred->taken_count[1] +
					pred->taken_count[2] + pred->taken_count[3],
					pred->not_taken_count[0], pred->not_taken_count[1],
					pred->not_taken_count[2], pred->not_taken_count[3],
					pred->not_taken_count[0] + pred->not_taken_count[1] +
					pred->not_taken_count[2] + pred->not_taken_count[3],
					state_names[pred->state]);
}



struct predictor global_predictor0;
struct predictor global_predictor1;
struct predictor global_predictor2;
struct predictor global_predictor3;
struct predictor global_predictor4;
struct predictor global_predictor5;
struct predictor global_predictor6;
struct predictor global_predictor7;
struct predictor global_predictor8;
struct predictor global_predictor9;

#endif
